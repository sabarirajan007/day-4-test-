/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main() {
    int array[100], n, i;

    printf("Enter the number of elements in the array: ");
    scanf("%d", &n);
    printf("Enter elements:\t %d \n", n);
    for (i = 0; i < n; i++) {
        scanf("%d", &array[i]);
    }

    printf("The elements of the array are:\n");
    for (i = 1; i < n; i++) {
        printf("%d ", array[i]);
    }

    return 0;
}
