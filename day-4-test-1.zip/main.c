/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int isPrime(int n, int i);

int main() {
    int n;
    printf("Enter a positive integer: ");
    scanf("%d", &n);
    if (isPrime(n, n / 2) == 1) {
        printf("%d is a prime no.\n", n);
        printf("%d the sum of the prime no\n",n+n);
    } 
    else {
        printf("%d is not a prime number.\n", n);
    }
    return 0;
}

int isPrime(int n, int i) {
    if (i == 1) {
        return 1;
    } else {
        if (n % i == 0) {
            return 0;
        } else {
            return isPrime(n, i - 1);
        }
    }
}

